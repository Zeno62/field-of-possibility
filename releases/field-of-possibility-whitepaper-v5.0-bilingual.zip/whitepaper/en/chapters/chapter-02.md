# 2｜Pure Possibility: Not the Beginning, but Total Knowing

A thought arises, and you know it. An emotion appears, and you know it. The body is in pain, and this pain can be noticed.

Then consciousness may establish a subtler position:

> “I am observing these things.”

But this observer-sense can itself be noticed. It can be vivid or faint; it can be described, remembered, or doubted. No matter how far “behind” experience it seems to stand, it remains content that is appearing.

> **If even the observer-sense belongs to the known, then Knowing is not the final “I” discovered by retreating farther and farther behind experience.**

## Cognitive activity and Knowing

Recognizing a person, remembering a sentence, judging right and wrong, comparing advantages, reasoning about causes, reflecting on oneself—these are cognitive activities within consciousness. They depend on particular relations and organizations, and they change.

Such activities can produce the sentence “I know.” But that sentence, together with the certainty it carries, can also be known. Cognitive activity does not gain an exemption from the known merely because it speaks about itself.

What this book calls Knowing is not the strongest of these capacities, nor is it another subject behind them performing an act of observation.

So long as an imagined observer can still become content, however subtle or lucid it may seem, it remains within the known. To place a still higher observer behind it merely adds another image that can be pointed to.

```text
the known may appear layer upon layer
Knowing does not therefore multiply
```

The issue is therefore not which self-image survives at the very end. It is to recognize that all such images—including “I am searching for the final me”—are already within the known.

## The Sole: this ontological ground, and no other

“Sole” does not mean counting one knower among all things, nor does it mean placing a supreme being outside all things.

The universe, the body, consciousness, and even an image of the universe as a whole already belong to appearance. If Luminosity is placed among them as a special member, then however vast, hidden, or eternal we make it, we are still describing an object.

To say that there are two or more Knowings, we would first have to say by what they differ.

If they are distinguished by position, boundary, property, history, or the contents known, the differentiating feature is already appearance. Different bodies, memories, and viewpoints can make conscious experience differ, but such differences do not divide Knowing into separate shares. Even merely labeling them “first” and “second” introduces a differentiating relation. Without anything by which the two are different, the labels do not establish a second Knowing.

This is one meaning of “sole”: Knowing cannot be divided into distinguishable instances.

But if we stop here, an erroneous picture can remain. On one side stands an indivisible Knowing; on the other stands a world that exists independently and faces it. Knowing is no longer many, yet ontology has silently become two.

What this book means by the sole includes a more radical “only”:

> **There is not only no second Knowing; there is also no second ontological ground standing alongside Luminosity in which the myriad appearances independently subsist.**

“No other” does not mean deleting everything and leaving behind one lonely supreme existence. Appearances may remain innumerable, relations complex, and the world full of sound, color, distance, arising, cessation, and change. But the myriad appearances do not each possess, beyond manifestation, another independent ontological ground of their own.

> **Luminosity is not another thing outside the myriad appearances; rather, none of the myriad appearances possesses another ontological ground.**

The word “only” has not been withdrawn. What has been withdrawn is the image of this “only” as a thing that can be pointed to, counted, and placed beside other things.

It is not the strongest among many grounds, nor the deepest object hidden behind many existents. Luminosity, Awareness, and Pure Possibility point to this ground without a second. The whole of manifestation is not another class of existence left outside it; it is the Totality of its manifestation.

The sole therefore does not become sole by excluding appearances. Precisely amid the multiplicity of appearances, no appearance thereby establishes an independent second ground.

> **The known is infinitely varied; Knowing has always been sole.**

Nor does this mean that different living beings originally possessed separate portions of Awareness which later merged into one. What differs are consciousness subnets and their manifested contents; Luminosity is not distributed into shares according to those differences.

## The layers are distinguishable; the ontological ground is nondual

The two-layer model must therefore not be read as two entities: one called Luminosity and one called the Mother Field, with Luminosity watching and the Mother Field being watched.

Layer One points to the sole Knowing; Layer Two to all that is known. Knowing cannot be replaced by one of the appearances within the known, yet the known does not stand on an ontological ground independent of it. There is a distinction that must be maintained, but there are not two mutually external grounds.

Ontological nonduality does not mean that Knowing and the known can be interchanged at will. A thought is a manifested appearance; it does not thereby become Knowing. Consciousness can organize experience; it does not thereby become another Awareness. Pain, memory, and the sense “I am observing” remain within the known.

“Not one of the appearances” is not the same as “unrelated to all appearances.” “Not separate from the ground” is not the same as “every appearance is itself Knowing.”

> **Knowing is not one appearance among the myriad appearances; the myriad appearances are not a second ontological ground outside Knowing.**

If distinction is used to establish two grounds, manifestation is split in two. If nonduality is used to erase the distinction between Knowing and the known, an appearance within consciousness is once again mistaken for Awareness. The two-layer formulation exists precisely so that we do not oscillate between these two errors.

## Why Pure Possibility is also Luminosity and Total Knowing

What we ordinarily call possibility often means a set of undetermined alternatives: something may happen this way or that way. Particular paths, conditions, probabilities, and choices are discussed within the relations of the Mother Field.

**Pure Possibility** is not the sum of those alternatives. The concretization of all possible relations is called Totality; the ontological capacity by which Totality can be concretized is what this book calls Pure Possibility.

But “concretization” here does not mean leaving behind something that is still merely possible and unmanifest. It means that a possible relation becomes established as a concrete appearance; the establishment of appearance is already the establishment of manifestation.

We must therefore ask:

> **If what is called concretization has not become any manifestation at all, in what sense has it become more than possibility?**

The Field of Possibility therefore treats concretization, manifestation, and being known as an inseparable ontological relation. A result does not first become independently established and then wait for another subject to arrive and observe it. Manifestation becoming established and manifestation being known are not two successive events.

Here, “being known” does not require a person’s attention to reach something first, nor does it wait for a consciousness to judge “I have recognized it.” Attention, recognition, and judgment are themselves manifested contents. They cannot become an external condition that all manifestation must wait upon.

The same ontological capacity can therefore be named from different directions:

From the capacity by which Totality can be concretized, it is called **Pure Possibility**. From the fact that all manifestation is within illumination, it is called **Luminosity** or **Awareness**. From the fact that no manifested appearance falls outside Knowing, it is called **Total Knowing**.

```text
Pure Possibility = Awareness = Luminosity = the sole Knowing = Total Knowing
```

This identity does not merge a creator, an observer, and an all-knowing being into one super-entity. It says that concretization and illumination are not two processes waiting upon one another.

> **The Totality of the Mother Field has never been outside Knowing.**

Total Knowing therefore does not mean that a local consciousness can retrieve all information. A person forgets, judges incorrectly, and encounters the unknown. These are relational states of consciousness and its contents; they are not Luminosity learning, forgetting, or waiting to be completed.

## The mirror analogy: the nonduality of emptiness and manifestation

Using a mirror and images as an analogy, Pure Possibility is like the reflecting surface and Totality like the totality of manifested images. What matters in the analogy is not the mirror as a physical object, its location, or an optical mechanism. It is this: however the images change, they cannot be treated as another ontological ground outside reflection, while reflection is not the final role left inside the image.

If we still try to find, outside all manifestation, a thing called “the mirror,” then the analogy has been turned back into an object. Luminosity is not that final thing waiting to be found.

Here the book uses **emptiness** and **manifestation** to point toward the same relation.

Emptiness is not a blank left after content has been removed. Blankness can be experienced; silence can be known. Having less content than noise does not make either of them the ontological ground. Here “emptiness” points to the fact that the ground is not determined by any particular appearance, and that there is no ground-object that can be extracted from the myriad appearances and grasped separately.

Manifestation, meanwhile, means that the myriad appearances do appear: sound, color, body, thought, relation, and the concretization of every possibility. They are not surplus content that must be denied, nor do they establish another order of existence outside the ground that has no appearance of its own.

To say that emptiness and manifestation are nondual does not mean that emptiness lies on one side and the world on another and must somehow be joined. Nor does it mean that emptiness finally reveals itself only after all things disappear. It means:

> **The ontological ground has no appearance of its own, yet the myriad appearances do not leave it; the myriad appearances manifest, yet the ground does not thereby become one appearance among them.**

Having no appearance does not prevent manifestation; manifestation does not establish another ground. A blank experience is not emptiness itself, and a feeling of solidity does not prove that an appearance subsists independently.

For the same reason, to say that **the myriad phenomena resolve into one ground** does not mean that all phenomena will at some future time be merged into one. They have never become ontologically other in the first place, and therefore do not require an event across time and space in order to acquire the same ground.

The “resolution” refers to what is recognized, not to the disappearance of appearances. The “one” points to the absence of a second ontological ground, not to a container into which everything is collected.

Differences can remain; relations can continue to unfold. We do not need every sound to become the same sound or every form to become the same form for this “one” to be evident.

> **The myriad phenomena do not finally become identical; they have simply never possessed another ontological ground.**

This concerns ontology and manifestation. It must not be confused with the later definition of Return as a process at the level of a particular consciousness.

## What language can do is not create one more image

Language easily turns what it points toward into an object.

Say “sole,” and it seems that a countable one has appeared. Say “ontological ground,” and it seems that some thing must be hidden behind the world. Say “emptiness,” and we imagine blankness. Say “Luminosity,” and we imagine a light.

But every image evoked by these words is already within the known.

This book therefore does not try to assemble a final “it” by piling on adjectives. Larger, deeper, higher, more luminous—none of these makes an image cease to be an image.

Even “indescribable” should not be used as a veil over some secret entity. What language cannot grasp here is not an object hidden too deeply. The difficulty is that once language determines it as a particular object, language has already altered what was being pointed toward.

For the moment, these formulations may serve as pointers:

> **Without an appearance of its own, yet not nothingness.**
>
> **Manifest as the myriad appearances, yet never one appearance among them.**
>
> **No appearance lies outside its ontological ground, yet no appearance can be selected and declared to be the whole of it.**

These are not final images. At this point “I understand” may arise; doubt may remain; or there may appear a self that seems to stand outside everything.

None of these reactions falls outside the known.

There is no need to place a higher observer behind them, and no need for them to cease before we can recognize that they are being known now.

The sole does not mean that, once all this has been said, only one invisible thing remains. Names, bodies, thoughts, earth and sky may still manifest, and they do not thereby constitute another ontological ground.

> **To say “only” is not to say that only one thing remains; to say “nondual” is not to flatten the myriad appearances. Appearances differ without end, while the ontological ground has never become two.**

Layer One points to the sole Knowing.

Layer Two points to all that is known.

They are not two objects looking at one another.

If an “observer” can still be discovered, it still belongs to the known. Searching for a subtler observer does not change that.

A new question now appears:

> **If the body, memory, and even the feeling “I am observing” all belong to the known, how does the ordinary “I,” so continuous and so solid, become formed?**

To pursue this “I,” we need to follow two lines: how these contents are organized relationally into a whole, and how that whole uses memory and prediction to acquire a sense of continuity from past into future.

First we will examine how relation allows a form to become established; then how temporal experience sustains continuity. Only then can we move more deeply into the formation of the self.

So the next question has not left the problem of “I” at all:

> **On what relations does an apparently independent existence depend in order to become established?**

---

